public class temp {
    public static void main(String[] args) {
        int Integer = 24;
        char String  = 'I';
        String yash = "Yash Shinde";
        System.out.print(Integer);
        System.out.print(yash);
    }
}
